﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EPazar.APIControls.APIControlBaseUrl
{
    internal static class BaseUrl 
    {
        public static string BaseHosting = "https://localhost:44318/";
    }
}
