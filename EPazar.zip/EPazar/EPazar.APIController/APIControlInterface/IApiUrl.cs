﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EPazar.APIControls.APIControlInterface
{
    public interface IApiUrl
    {
        public string UrlUrunleriGuncelle { get; }
    }
}
