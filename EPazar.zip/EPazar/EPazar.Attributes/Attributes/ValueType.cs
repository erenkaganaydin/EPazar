﻿namespace EPazar.Attributes.Attributes
{
    public enum ValueType : int
    {
        Int16,
        Int32,
        Int64,
        Double,
        Decimal,
        String,
        Boolean,
        Single
    }
}
