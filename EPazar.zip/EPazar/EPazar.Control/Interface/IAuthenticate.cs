﻿namespace EPazar.Control.Interface
{
    public interface IAuthenticate
    {
        string Authenticate(string userName, string password);
    }
}