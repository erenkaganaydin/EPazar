﻿using EPazar.Entity.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EPazar.Entity.SanalEntity
{
    public class NavbarEntityleri
    {
        public List<AnaKategoriler> AnaKategorilerList { get; set; }
        public List<Kategoriler> KategorilerList { get; set; }
        public List<AltKategoriler> AltKategorilerList { get; set; }
    }
}
