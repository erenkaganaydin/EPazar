﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EPazar.Entity.SanalEntity
{
    public class TedarikKategorileri
    {
        public string? TedarikciKategoriBirAdi { get; set; }
        public string? TedarikciKategoriIkiAdi { get; set; }
        public string? TedarikciKategoriUcAdi { get; set; }
    }
}
