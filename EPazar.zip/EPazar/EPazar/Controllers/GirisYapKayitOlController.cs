﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace EPazar.Controllers
{
    public class GirisYapKayitOlController : Controller
    {
        private readonly ILogger<GirisYapKayitOlController> _logger;

        public GirisYapKayitOlController(ILogger<GirisYapKayitOlController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult OturumAc()
        {
            return View();
        }
    }
}
